package promjenaboje;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DateEditor;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class PromjenaBoje {

    static Integer elapsed;
    static Integer elapsed1;
    static Integer elapsed2;
    static JFrame okvirZaBoje;
    static JColorChooser jcc;
   
    static JSlider slider;
    static Timer promjena;

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame f = new JFrame();
                f.setSize(290, 350);
                f.setLocation(250, 100);

                JFrame okvirBoje = new JFrame();
                okvirBoje.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JButton boja = new JButton("Izaberi boju");
                JTextField color = new JTextField("Boja nije izabrana", 13);
                JButton boja1 = new JButton("Izaberi boju");
                JTextField color1 = new JTextField("Boja nije izabrana", 13);
                JButton boja2 = new JButton("Izaberi boju");
                JTextField color2 = new JTextField("Boja nije izabrana", 13);
                JButton boja3 = new JButton("Izaberi boju");
                JTextField color3 = new JTextField("Boja nije izabrana", 13);
                JButton zatvori = new JButton("Zavrsi izbor boja");

                JFrame okvir = new JFrame();
                okvir.setSize(290, 300);
                okvir.setLayout(new FlowLayout());
                okvir.setLocation(500, 200);

                ButtonGroup radioGrupa = new ButtonGroup();
                JRadioButton naSat = new JRadioButton("Na Vrijeme:                       ");
                JRadioButton naOdbrojavanje = new JRadioButton("Na Odbrojavanje:                           ");
                radioGrupa.add(naSat);
                radioGrupa.add(naOdbrojavanje);

            /*    Calendar cal = Calendar.getInstance();
                Date now = cal.getTime();
                cal.add(Calendar.YEAR, -5);
                Date min = cal.getTime();
                cal.add(Calendar.YEAR, 5);*/
               
                SpinnerDateModel sdm = new SpinnerDateModel();//(now,now, null, Calendar.SECOND);

                JSpinner sat = new JSpinner(sdm);
                DateEditor timeEditor = new DateEditor(sat, "HH:mm:ss");
                sat.setEditor(timeEditor);
                sat.getValue();

                sat.addChangeListener(
                        new ChangeListener() {
                            public void stateChanged(ChangeEvent e) {
                                sat.getValue();

                            }
                        }
                );

                SpinnerNumberModel odbrojavanje = new SpinnerNumberModel();

                JSpinner spinerOdbrojavanje = new JSpinner(odbrojavanje);

                odbrojavanje.setMinimum(00);

                JButton izborBoje = new JButton("Izaberi boje");
                JButton pocni = new JButton("Pocni");
                JButton zavrsi = new JButton("Zavrsi");

                JLabel izabranaBoja = new JLabel("    Nisu Izabrane Boje");
                JLabel brzina = new JLabel("    Izaberi Brzinu Promjene Boje");

                JSlider brzinaBoje = new JSlider(0, 30, 0);

                brzinaBoje.setMajorTickSpacing(10);
                brzinaBoje.setMinorTickSpacing(100);
                brzinaBoje.setPaintTicks(true);
                Hashtable<Integer, JLabel> labels = new Hashtable<Integer, JLabel>();

                labels.put(1, new JLabel("100 ms"));
                labels.put(10, new JLabel("1 sec"));
                labels.put(20, new JLabel("2 sec"));
                labels.put(30, new JLabel("3 sec"));
                brzinaBoje.setLabelTable(labels);

                brzinaBoje.setPaintLabels(true);

                JTextArea ostalo = new JTextArea();
                JTextArea ostalo1 = new JTextArea();
                JTextArea ostalo2 = new JTextArea();

                brzinaBoje.addChangeListener(
                        new javax.swing.event.ChangeListener() {

                            @Override
                            public void stateChanged(ChangeEvent arg0
                            ) {
                                brzinaBoje.getValue();
                                promjena.restart();
                                pocni.setEnabled(true);
                            }
                        }
                );
                promjena = new Timer(1, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        elapsed = Integer.valueOf(brzinaBoje.getValue()) * 4;

                    }
                });
                Timer t = new Timer(100, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        elapsed--;

                    }
                });
                Timer t1 = new Timer(1000, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        ostalo.setText("Aplikacija ce startovati za : " + (elapsed1--).toString() + "  sekundi");

                    }
                });

                jcc = new JColorChooser();

                boja.addActionListener(
                        new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e
                            ) {

                                JDialog dialog = JColorChooser.createDialog(null, "Choose color", true, jcc, new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        Color c = jcc.getColor();
                                        color.setBackground(c);
                                        if (c.getRed() == 255 && c.getGreen() == 255 && c.getBlue() == 255) {
                                            color.setText("    Bijela");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 0 && c.getGreen() == 0 && c.getBlue() == 0) {
                                            color.setText("    Crna");
                                            color.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 204 && c.getGreen() == 204 && c.getBlue() == 204) {
                                            color.setText("    Srebrna");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 204 && c.getGreen() == 204 && c.getBlue() == 255) {
                                            color.setText("    Siva");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 102 && c.getGreen() <= 102 && c.getBlue() == 255) {
                                            color.setText("    Plava");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 204 && c.getGreen() == 255 && c.getBlue() == 255) {
                                            color.setText("    Tirkizna");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() <= 153 && c.getBlue() == 255) {
                                            color.setText("    Roze");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() <= 102 && c.getBlue() <= 102) {
                                            color.setText("    Crvena");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 153 && c.getGreen() == 0 && c.getBlue() == 153) {
                                            color.setText("    Ljubicasta");
                                            color.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 255 && c.getGreen() == 204 && c.getBlue() <= 153) {
                                            color.setText("    Narandzasta");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 204 && c.getGreen() == 255 && c.getBlue() <= 204) {
                                            color.setText("    Zelena");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() == 255 && c.getBlue() <= 204) {
                                            color.setText("    Zuta");
                                            color.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 128 && c.getGreen() == 0 && c.getBlue() == 0) {
                                            color.setText("    Braon");
                                            color.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 102 && c.getGreen() == 102 && c.getBlue() == 0) {
                                            color.setText("    Maslinasta");
                                            color.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 0 && c.getGreen() == 0 && c.getBlue() == 128) {
                                            color.setText("    Teget");
                                            color.setForeground(new java.awt.Color(255, 255, 255));
                                        } else {
                                            color.setText("Ime boje nije nadjeno");
                                            color.setForeground(new java.awt.Color(255, 255, 255));
                                        }
                                        
                                        t.addActionListener(new ActionListener() {
                                            public void actionPerformed(ActionEvent e) {

                                                if (elapsed == (Integer.valueOf(brzinaBoje.getValue()) * 4)) {

                                                    f.getContentPane().setBackground(c);

                                                    f.setVisible(true);
                                                }
                                                if (elapsed == (Integer.valueOf(brzinaBoje.getValue()) * 3)) {
                                                    t.stop();
                                                    elapsed = (Integer.valueOf(brzinaBoje.getValue()) * 3);
                                                    t.start();
                                                }
                                            }
                                        });
                                    }
                                }, null);
                                dialog.setVisible(true);
                               

                            }

                        }
                );
                boja1.addActionListener(
                        new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e
                            ) {

                                JDialog dialog = JColorChooser.createDialog(null, "Choose color", true, jcc, new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        Color c = jcc.getColor();
                                             color1.setBackground(c);
                                             if (c.getRed() == 255 && c.getGreen() == 255 && c.getBlue() == 255) {
                                            color1.setText("    Bijela");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 0 && c.getGreen() == 0 && c.getBlue() == 0) {
                                            color1.setText("    Crna");
                                            color1.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 204 && c.getGreen() == 204 && c.getBlue() == 204) {
                                            color1.setText("    Srebrna");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 204 && c.getGreen() == 204 && c.getBlue() == 255) {
                                            color1.setText("    Siva");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 102 && c.getGreen() <= 102 && c.getBlue() == 255) {
                                            color1.setText("    Plava");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 204 && c.getGreen() == 255 && c.getBlue() == 255) {
                                            color1.setText("    Tirkizna");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() <= 153 && c.getBlue() == 255) {
                                            color1.setText("    Roze");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() <= 102 && c.getBlue() <= 102) {
                                            color1.setText("    Crvena");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 153 && c.getGreen() == 0 && c.getBlue() == 153) {
                                            color1.setText("    Ljubicasta");
                                            color1.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 255 && c.getGreen() == 204 && c.getBlue() <= 153) {
                                            color1.setText("    Narandzasta");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 204 && c.getGreen() == 255 && c.getBlue() <= 204) {
                                            color1.setText("    Zelena");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() == 255 && c.getBlue() <= 204) {
                                            color1.setText("    Zuta");
                                            color1.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 128 && c.getGreen() == 0 && c.getBlue() == 0) {
                                            color1.setText("    Braon");
                                            color1.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 102 && c.getGreen() == 102 && c.getBlue() == 0) {
                                            color1.setText("    Maslinasta");
                                            color1.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 0 && c.getGreen() == 0 && c.getBlue() == 128) {
                                            color1.setText("    Teget");
                                            color1.setForeground(new java.awt.Color(255, 255, 255));
                                        } else {
                                            color1.setText("Ime boje nije nadjeno");
                                            color1.setForeground(new java.awt.Color(255, 255, 255));
                                        }
                                        t.addActionListener(new ActionListener() {
                                            public void actionPerformed(ActionEvent e) {

                                                if (elapsed == (Integer.valueOf(brzinaBoje.getValue()) * 3)) {

                                                    f.getContentPane().setBackground(c);
                                                    f.setVisible(true);

                                                }
                                                if (elapsed == (Integer.valueOf(brzinaBoje.getValue()) * 2)) {
                                                    t.stop();
                                                    elapsed = (Integer.valueOf(brzinaBoje.getValue()) * 2);
                                                    t.start();
                                                }
                                            }
                                        });
                                    }
                                }, null);
                                dialog.setVisible(true);

                             

                            }

                        }
                );
                boja2.addActionListener(
                        new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e
                            ) {

                                JDialog dialog = JColorChooser.createDialog(null, "Choose color", true, jcc, new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        Color c = jcc.getColor();
                                        color2.setBackground(c);
                                             if (c.getRed() == 255 && c.getGreen() == 255 && c.getBlue() == 255) {
                                            color2.setText("    Bijela");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 0 && c.getGreen() == 0 && c.getBlue() == 0) {
                                            color2.setText("    Crna");
                                            color2.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 204 && c.getGreen() == 204 && c.getBlue() == 204) {
                                            color2.setText("    Srebrna");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 204 && c.getGreen() == 204 && c.getBlue() == 255) {
                                            color2.setText("    Siva");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 102 && c.getGreen() <= 102 && c.getBlue() == 255) {
                                            color2.setText("    Plava");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 204 && c.getGreen() == 255 && c.getBlue() == 255) {
                                            color2.setText("    Tirkizna");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() <= 153 && c.getBlue() == 255) {
                                            color2.setText("    Roze");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() <= 102 && c.getBlue() <= 102) {
                                            color2.setText("    Crvena");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 153 && c.getGreen() == 0 && c.getBlue() == 153) {
                                            color2.setText("    Ljubicasta");
                                            color2.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 255 && c.getGreen() == 204 && c.getBlue() <= 153) {
                                            color2.setText("    Narandzasta");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 204 && c.getGreen() == 255 && c.getBlue() <= 204) {
                                            color2.setText("    Zelena");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() == 255 && c.getBlue() <= 204) {
                                            color2.setText("    Zuta");
                                            color2.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 128 && c.getGreen() == 0 && c.getBlue() == 0) {
                                            color2.setText("    Braon");
                                            color2.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 102 && c.getGreen() == 102 && c.getBlue() == 0) {
                                            color2.setText("    Maslinasta");
                                            color2.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 0 && c.getGreen() == 0 && c.getBlue() == 128) {
                                            color2.setText("    Teget");
                                            color2.setForeground(new java.awt.Color(255, 255, 255));
                                        } else {
                                            color2.setText("Ime boje nije nadjeno");
                                            color2.setForeground(new java.awt.Color(255, 255, 255));
                                        }
                                        t.addActionListener(new ActionListener() {
                                            public void actionPerformed(ActionEvent e) {

                                                if (elapsed == (Integer.valueOf(brzinaBoje.getValue()) * 2)) {

                                                    f.getContentPane().setBackground(c);

                                                }
                                                if (elapsed == Integer.valueOf(brzinaBoje.getValue())) {
                                                    t.stop();
                                                    elapsed = Integer.valueOf(brzinaBoje.getValue());
                                                    t.start();
                                                }
                                            }
                                        });

                                    }
                                }, null);
                                dialog.setVisible(true);

                              

                            }

                        }
                );

                boja3.addActionListener(
                        new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e
                            ) {
                                JDialog dialog = JColorChooser.createDialog(null, "Choose color", true, jcc, new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        Color c = jcc.getColor();
                                        zatvori.setEnabled(true);
                                        color3.setBackground(c);
                                             if (c.getRed() == 255 && c.getGreen() == 255 && c.getBlue() == 255) {
                                            color3.setText("    Bijela");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 0 && c.getGreen() == 0 && c.getBlue() == 0) {
                                            color3.setText("    Crna");
                                            color3.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 204 && c.getGreen() == 204 && c.getBlue() == 204) {
                                            color3.setText("    Srebrna");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 204 && c.getGreen() == 204 && c.getBlue() == 255) {
                                            color3.setText("    Siva");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 102 && c.getGreen() <= 102 && c.getBlue() == 255) {
                                            color3.setText("    Plava");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 204 && c.getGreen() == 255 && c.getBlue() == 255) {
                                            color3.setText("    Tirkizna");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() <= 153 && c.getBlue() == 255) {
                                            color3.setText("    Roze");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() <= 102 && c.getBlue() <= 102) {
                                            color3.setText("    Crvena");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 153 && c.getGreen() == 0 && c.getBlue() == 153) {
                                            color3.setText("    Ljubicasta");
                                            color3.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 255 && c.getGreen() == 204 && c.getBlue() <= 153) {
                                            color3.setText("    Narandzasta");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() <= 204 && c.getGreen() == 255 && c.getBlue() <= 204) {
                                            color3.setText("    Zelena");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 255 && c.getGreen() == 255 && c.getBlue() <= 204) {
                                            color3.setText("    Zuta");
                                            color3.setForeground(new java.awt.Color(0, 0, 0));
                                        } else if (c.getRed() == 128 && c.getGreen() == 0 && c.getBlue() == 0) {
                                            color3.setText("    Braon");
                                            color3.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 102 && c.getGreen() == 102 && c.getBlue() == 0) {
                                            color3.setText("    Maslinasta");
                                            color3.setForeground(new java.awt.Color(255, 255, 255));
                                        } else if (c.getRed() == 0 && c.getGreen() == 0 && c.getBlue() == 128) {
                                            color3.setText("    Teget");
                                            color3.setForeground(new java.awt.Color(255, 255, 255));
                                        } else {
                                            color3.setText("Ime boje nije nadjeno");
                                            color3.setForeground(new java.awt.Color(255, 255, 255));
                                        }
                                        t.addActionListener(new ActionListener() {
                                            public void actionPerformed(ActionEvent e) {

                                                if (elapsed == Integer.valueOf(brzinaBoje.getValue())) {

                                                    f.getContentPane().setBackground(c);

                                                }
                                                if (elapsed == 0) {
                                                    t.stop();
                                                    elapsed = (Integer.valueOf(brzinaBoje.getValue()) * 4);
                                                    t.start();
                                                }

                                            }
                                        });

                                    }
                                }, null);
                                dialog.setVisible(true);

                             

                            }

                        }
                );
                zatvori.addActionListener(
                        new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e
                            ) {

                                okvirBoje.dispose();
                                color.setBackground(null);
                                color.setText("Boja nije izabrana");
                                color1.setBackground(null);
                                color1.setText("Boja nije izabrana");
                                color2.setBackground(null);
                                color2.setText("Boja nije izabrana");
                                color3.setBackground(null);
                                color3.setText("Boja nije izabrana");
                                izabranaBoja.setText("Izabrali ste Boje");

                            }
                        }
                );

                izborBoje.addActionListener(
                        new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e
                            ) {

                                okvirBoje.repaint();
                                okvirBoje.setSize(290, 300);
                                okvirBoje.setLayout(new FlowLayout());
                                okvirBoje.setLocation(500, 200);

                                okvirBoje.setLocation(400, 150);
                                okvirBoje.add(boja);
                                okvirBoje.add(color);
                                color.setEditable(false);
                                okvirBoje.add(boja1);
                                okvirBoje.add(color1);
                                color1.setEditable(false);

                                okvirBoje.add(boja2);
                                okvirBoje.add(color2);
                                color2.setEditable(false);
                                okvirBoje.add(boja3);
                                okvirBoje.add(color3);
                                color3.setEditable(false);

                                okvirBoje.add(zatvori);
                                zatvori.setEnabled(false);

                                okvirBoje.setVisible(true);
                            }
                        }
                );
                pocni.addActionListener(
                        new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e
                            ) {

                                pocni.setEnabled(false);
                                izborBoje.setEnabled(false);
                                sat.setEnabled(false);
                                spinerOdbrojavanje.setEnabled(false);
                                brzinaBoje.setEnabled(false);
                                naSat.setEnabled(false);
                                naOdbrojavanje.setEnabled(false);
                                //okvir.setVisible(false);
                            }
                        }
                );

                DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
                ActionListener timerListener = new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        Date date = new Date();
                        String time = timeFormat.format(date);
                        String[] pharse = time.split(":");
                        String naVrijeme = pharse[0] + pharse[1] + pharse[2];
                        String josIma = timeFormat.format(sat.getValue());
                        okvir.setTitle("Vrijeme : " + time);
                        String time1 = timeFormat.format(sat.getValue());
                        String[] pharse1 = time1.split(":");
                        String uVrijeme = pharse1[0] + pharse1[1] + pharse1[2];

                        if (naSat.isSelected()) {

                            ostalo1.setText("Trenutno vrijeme :" + time);

                            ostalo2.setText("Aplikacija startuje u :" + josIma);

                            okvir.add(ostalo2);

                            
                            if (uVrijeme == null ? naVrijeme == null : uVrijeme.equals(naVrijeme)) {
                                t.setInitialDelay(0);
                                t.start();
                                ostalo2.setVisible(false);
                                f.setVisible(true);
                                f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

                            }

                        }

                    }

                };
                Timer timer = new Timer(1000, timerListener);

                timer.setInitialDelay(0);
                timer.start();
                pocni.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (naSat.isSelected()) {
                            ostalo1.setVisible(true);
                            ostalo2.setVisible(true);
                        }
                    }
                });

                pocni.addActionListener(
                        new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {

                                if (naOdbrojavanje.isSelected()) {
                                    elapsed1 = (Integer) spinerOdbrojavanje.getValue();
                                    t1.setInitialDelay(0);
                                    t1.start();
                                    okvir.add(ostalo);
                                    ostalo.setVisible(true);

                                }

                            }
                        }
                );

                t1.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent e) {

                        if (elapsed1 == 0) {
                            t1.stop();
                            t.setInitialDelay(0);
                            t.start();
                            ostalo.setVisible(false);
                            f.setVisible(true);
                            f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

                        }
                    }
                }
                );

                zavrsi.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        t.stop();
                        f.dispose();
                        izabranaBoja.setText("    Nisu Izabrane Boje");
                        pocni.setEnabled(false);
                        izborBoje.setEnabled(true);
                        sat.setEnabled(true);
                        spinerOdbrojavanje.setEnabled(true);
                        spinerOdbrojavanje.setValue(0);
                        brzinaBoje.setEnabled(true);
                        brzinaBoje.setValue(0);
                        naSat.setEnabled(true);
                        naOdbrojavanje.setEnabled(true);
                        naSat.setSelected(false);
                        naOdbrojavanje.setSelected(false);
                        ostalo.setVisible(false);
                        ostalo1.setVisible(false);
                        ostalo2.setVisible(false);
                        if (brzinaBoje.getValue() == 0) {
                            pocni.setEnabled(false);
                        }
                    }

                });

                PopupMenu pocetniProzor = new PopupMenu();
                MenuItem podesavanja = new MenuItem("Podesavanja");
                MenuItem izlaz = new MenuItem("Zatvori");

                izlaz.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        System.exit(0);
                    }
                });
                podesavanja.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        okvir.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                        okvir.add(naSat);
                        okvir.add(sat);
                        okvir.add(naOdbrojavanje);
                        okvir.add(spinerOdbrojavanje);
                        okvir.add(izborBoje);
                        okvir.add(izabranaBoja);
                        okvir.add(brzina);
                        okvir.add(brzinaBoje);
                        okvir.add(pocni);
                        pocni.setEnabled(false);
                        okvir.add(zavrsi);
                        okvir.setVisible(true);
                        promjena.setRepeats(
                                false);
                    }
                });
                pocetniProzor.add(podesavanja);
                pocetniProzor.add(izlaz);
                SystemTray st = SystemTray.getSystemTray();
                try {
                    Image img = ImageIO.read(new File("Color-Swatch.png"));
                    TrayIcon myTray = new TrayIcon(img);
                    myTray.setToolTip("Klikni desni taster misa za opcije");
                    myTray.setPopupMenu(pocetniProzor);

                    st.add(myTray);
                } catch (Exception ex) {
                }

            }
        }
        );

    }
}
